module.exports = {
  HOST: "localhost",
  PORT: "1400",
  USER: "sa",
  PASSWORD: "Keshri6@1990",
  DB: "test",
  dialect: "mssql",
  pool: {
    max: 5,
    min: 0,
    acquire: 30000,
    idle: 10000
  }
};
